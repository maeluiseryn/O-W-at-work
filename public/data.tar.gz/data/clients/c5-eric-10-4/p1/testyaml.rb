require 'yaml'

class Objetest
  def initialize word , time
    @word=word
    @time=time
  end
end  

